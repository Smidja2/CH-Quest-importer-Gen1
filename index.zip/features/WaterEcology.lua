local mod=...

local WATER_ECOLOGY_KEY="quest_water_ecology"
local FLYING_ECOLOGY_KEY="quest_flying_ecology"
local OVERWORLD_WILDS_KEY="overworld_wilds"

local function liveGame()
  local g=mod and mod.game
  return type(g)=="table" and g or nil
end
local Game=setmetatable({}, {
  __index=function(_,k)
    local g=liveGame(); if not g then return nil end
    if k=="overworld" then return g.overworld or g.world end
    return g[k]
  end,
  __newindex=function(_,k,v) local g=liveGame(); if g then g[k]=v end end,
})

local function optionValue(key,default)
  local loader=Game and Game.mods
  local st=loader and loader.modOptions and loader.modOptions[mod.id]
  local v=st and st[key]
  if v==nil then
    local opts=Game and Game.save and Game.save.options
    st=opts and opts.modOptions and opts.modOptions[mod.id]
    v=st and st[key]
  end
  if v==nil then return default end
  return v
end
local function optionOn(key,default)
  local v=optionValue(key,default)
  return v~=false and v~=0 and v~="OFF" and v~="NO"
end
local function enabled()
  return optionOn(OVERWORLD_WILDS_KEY,true) and optionOn(WATER_ECOLOGY_KEY,true)
end
local function birdEcologyEnabled()
  return optionOn(FLYING_ECOLOGY_KEY,true)
end

local CELL=16
local TOUCH_RADIUS=10
local SWIM_SPEED=18
local FLEE_SPEED=45
local RESPAWN_INTERVAL=1.2
local BIRD_SCAN_MIN=8.0
local BIRD_SCAN_MAX=16.0
local BIRD_SPAWN_CHANCE=0.40
local BIRD_ALTITUDE=38
local BIRD_ORBIT_TIME=1.8
local BIRD_SWOOP_SPEED=62
local BIRD_ESCAPE_SPEED=72

-- Availability is taken from the live water encounter distribution.
-- Native Game.data remains the normal source. An optional, clearly marked
-- Kanto-Reforged adapter can additionally expose src.core.Data.encounters.
-- No separate route/species whitelist is maintained here.

local TENTACOOL_FAMILY={ [72]=true,[73]=true }
local WATER_HOVERERS={ [226]=true,[278]=true,[279]=true } -- Mantine + Wingull/Pelipper
local WATER_FLYING_BIRDS={ [278]=true,[279]=true }

local members={}
local waterCells={}
local waterDist=nil
local activeMapId=nil
local Voxel3D=nil
local BLACK=nil
local servicesReady=false
local spawnClock=0
local availabilityClock=0
local birdClock=5
local bird=nil
local battleLock=false

local function rnd(a,b) return (love and love.math and love.math.random) and love.math.random(a,b) or math.random(a,b) end
local function rnd01() return (love and love.math and love.math.random) and love.math.random() or math.random() end
local function clamp(v,a,b) if v<a then return a elseif v>b then return b else return v end end
local function importer() return mod.exports and (mod.exports.quest_main or mod.exports.quest_importer) end
local function companion() return mod.exports and mod.exports.voxel_companion end
local function wildAPI() return mod.exports and mod.exports.quest_overworld_wilds or {} end

local function dexOfSpecies(species)
  if type(species)=="number" then
    local d=math.floor(species); if d>=1 and d<=386 then return d end
  end
  local data=Game and Game.data
  local pokemon=data and data.pokemon
  if type(pokemon)~="table" or species==nil then return nil end
  local key=tostring(species):upper()
  local def=pokemon[species] or pokemon[key]
  local dex=def and tonumber(def.dex)
  if dex and dex>=1 and dex<=493 then return math.floor(dex) end
  for k,v in pairs(pokemon) do
    if type(v)=="table" then
      local n=tostring(v.name or v.species or ""):upper()
      if n==key then
        local d=tonumber(v.dex) or tonumber(k)
        if d and d>=1 and d<=386 then return math.floor(d) end
      end
    end
  end
  return nil
end

local function speciesOfDex(dex)
  dex=tonumber(dex); if not dex then return nil end
  if mod.content and mod.content.pokemon and type(mod.content.pokemon.get)=="function" then
    local ok,rec=pcall(mod.content.pokemon.get,mod.content.pokemon,dex)
    if ok and rec and tonumber(rec.dex)==dex then return rec.id or rec.species or dex end
  end
  local data=Game and Game.data
  local pokemon=data and data.pokemon
  if type(pokemon)=="table" then
    for k,v in pairs(pokemon) do
      if type(v)=="table" and math.floor(tonumber(v.dex) or tonumber(k) or -1)==dex then
        return v.id or v.species or k
      end
    end
  end
  return dex
end

-- Optional encounter-source extension hook. If the marked KR block is
-- removed, Water Ecology continues to use only the normal live game data.
local kantoReforgedWaterSources=function() return {} end

-- ============================================================================
-- KANTO-REFORGED WATER ECOLOGY START
-- SAFE TO DELETE THIS WHOLE BLOCK if Kanto-Reforged support is not wanted.
-- Water Ecology will continue to work from Game.data/effectiveEncounters.
-- ============================================================================
local KR_WATER_CORE_DATA=nil
local KR_WATER_CORE_DATA_TRIED=false

kantoReforgedWaterSources=function()
  if not KR_WATER_CORE_DATA_TRIED then
    KR_WATER_CORE_DATA_TRIED=true
    local ok,d=pcall(require,"src.core.Data")
    if ok and type(d)=="table" then KR_WATER_CORE_DATA=d end
  end

  local out={}
  if KR_WATER_CORE_DATA and type(KR_WATER_CORE_DATA.encounters)=="table" then
    out[#out+1]=KR_WATER_CORE_DATA.encounters
  end
  return out
end
-- ============================================================================
-- KANTO-REFORGED WATER ECOLOGY END
-- ============================================================================

local function waterEncounterSources()
  local out,seen={},{}
  local function add(t)
    if type(t)=="table" and not seen[t] then
      seen[t]=true
      out[#out+1]=t
    end
  end
  add(Game and Game.data and Game.data.encounters)
  for _,t in ipairs(kantoReforgedWaterSources() or {}) do add(t) end
  return out
end

local function scanWaterSlots(slots,fn)
  if type(slots)~="table" or type(fn)~="function" then return end
  if slots[1] then
    for _,slot in ipairs(slots) do fn(slot) end
  else
    for _,bucket in pairs(slots) do
      if type(bucket)=="table" then
        if bucket.species~=nil then fn(bucket)
        else scanWaterSlots(bucket,fn) end
      end
    end
  end
end

local function waterLevel(mapId,species)
  local sum,n,any=0,0,nil
  for _,data in ipairs(waterEncounterSources()) do
    local entry=type(data)=="table" and data[mapId] or nil
    local water=entry and entry.water
    if type(water)=="table" and (water.rate==nil or (tonumber(water.rate) or 0)>0) then
      scanWaterSlots(water.slots,function(slot)
        if type(slot)=="table" and slot.level then
          local lv=tonumber(slot.level)
          if lv then
            any=any or lv
            if slot.species==species or dexOfSpecies(slot.species)==dexOfSpecies(species) then
              sum=sum+lv;n=n+1
            end
          end
        end
      end)
    end
  end
  return n>0 and math.floor(sum/n+0.5) or any or 5
end

local function loadWaterDistribution(mapId)
  local dist={}
  local nativeEffective=false
  local function addSpecies(species,wt)
    local dex=dexOfSpecies(species)
    wt=tonumber(wt) or 0
    if dex and dex>=1 and dex<=386 and wt>0 then
      dist[species]=(dist[species] or 0)+wt
    end
  end

  -- Keep the game's live/effective water resolver as the primary native source
  -- so scope/time/version filtering still works exactly as before.
  if mod.world and type(mod.world.effectiveEncounters)=="function" then
    local ok,res=pcall(mod.world.effectiveEncounters,mod.world,mapId,"water")
    if ok and type(res)=="table" and next(res.dist or {}) and (res.chance==nil or (tonumber(res.chance) or 0)>0) then
      for species,wt in pairs(res.dist or {}) do addSpecies(species,wt) end
      nativeEffective=next(dist)~=nil
    end
  end

  local nativeData=Game and Game.data and Game.data.encounters
  local function addEncounterTable(data)
    local enc=type(data)=="table" and data[mapId] or nil
    local water=enc and enc.water
    if type(water)~="table" or not (water.rate==nil or (tonumber(water.rate) or 0)>0) then return end
    scanWaterSlots(water.slots,function(slot)
      if type(slot)=="table" and slot.species then addSpecies(slot.species,1) end
    end)
  end

  -- If no effective resolver produced native water encounters, fall back to the
  -- raw native table. Then union the optional KR Data.encounters water table.
  if not nativeEffective then addEncounterTable(nativeData) end
  for _,data in ipairs(kantoReforgedWaterSources() or {}) do
    if data~=nativeData then addEncounterTable(data) end
  end

  return next(dist) and dist or nil
end

local function pickWaterSpecies()
  if type(waterDist)~="table" then return nil end
  local total=0
  for _,wt in pairs(waterDist) do total=total+(tonumber(wt) or 0) end
  if total<=0 then return nil end
  local r=rnd01()*total
  for species,wt in pairs(waterDist) do
    r=r-(tonumber(wt) or 0)
    if r<=0 then return species,dexOfSpecies(species) end
  end
  for species in pairs(waterDist) do return species,dexOfSpecies(species) end
end

local function distributionHasSpecies(dist,species)
  return type(dist)=="table" and species~=nil and (tonumber(dist[species]) or 0)>0
end

local function scanWater(map)
  waterCells={}
  if not (map and map.isWaterCell and map.widthCells and map.heightCells) then return end
  local W,H=tonumber(map.widthCells),tonumber(map.heightCells)
  if not W or not H then return end
  for z=0,H-1 do
    for x=0,W-1 do
      local ok,v=pcall(map.isWaterCell,map,x,z)
      if ok and v then waterCells[#waterCells+1]={x,z} end
    end
  end
end

local function occupied(x,z,ignore)
  for _,m in ipairs(members) do
    if m~=ignore and m.cx==x and m.cz==z then return true end
  end
  return false
end
local function pos(cx,cz,y) return cx*CELL+8,y or 0,cz*CELL+8 end

local function depthFor(dex)
  if WATER_FLYING_BIRDS[dex] then return 14+rnd01()*5,"fly" end
  if WATER_HOVERERS[dex] then return 8+rnd01()*3,"fly" end
  if TENTACOOL_FAMILY[dex] then
    if rnd01()<0.55 then return 1.2,"surface" else return -4.5,"under" end
  end
  return -3.2,"half"
end

local function hasAuthoredClip(actor,name)
  local model=actor and actor.model
  return model and model.anims and model.anims[name]~=nil
end

local function hasSurfState(actor)
  local model=actor and actor.model
  return model and model.states and model.states.surf~=nil
end

local function waterMoveAnim(actor,dex)
  -- Exact Quest ecology mapping: Water uses Mmotion_idle_float through water_idle. No fallback chain.
  return "water_idle",false
end

local function createMember(species,dex,cx,cz)
  local api=importer(); if not (api and type(api.createActor)=="function" and dex) then return nil end
  local y,style=depthFor(dex)
  local x,yy,z=pos(cx,cz,y)
  local a=api.createActor(dex,{manual=true,visible=false,x=x,y=yy,z=z})
  if not a then return nil end
  if a.setGroundY then a:setGroundY(0) end
  local anim,wobble=waterMoveAnim(a,dex)
  a:setAnimation(anim); a:setVisible(false)
  local m={species=species,dex=dex,level=waterLevel(activeMapId,species),actor=a,
           x=x,y=yy,z=z,cx=cx,cz=cz,tcx=nil,tcz=nil,tx=nil,tz=nil,
           style=style,moveClock=1+rnd01()*2,lastAnim=anim,contact=false,
           fleeClock=0,wobble=wobble,wobblePhase=rnd01()*math.pi*2}
  members[#members+1]=m
  return m
end

local function destroyMember(m)
  if m and m.actor then pcall(function() m.actor:destroy() end);m.actor=nil end
end
local function clearBird()
  if bird and bird.actor then pcall(function() bird.actor:destroy() end) end
  bird=nil
end
local function clear()
  for _,m in ipairs(members) do destroyMember(m) end
  members={};waterCells={};waterDist=nil;battleLock=false;clearBird()
end

local function black()
  if BLACK then return BLACK end
  if not (love and love.image and love.graphics) then return nil end
  local ok,d=pcall(love.image.newImageData,1,1);if not ok then return nil end
  pcall(d.setPixel,d,0,0,0,0,0,1)
  local ok2,i=pcall(love.graphics.newImage,d);if ok2 then BLACK=i end
  return BLACK
end
local function drawActor(a)
  if not (a and Voxel3D and type(Voxel3D.draw)=="function") then return end
  if type(a.shouldRender)=="function" and not a:shouldRender() then return end
  local mat=a:matrix();local b=black();local api=importer()
  local outline=not api or type(api.outlineEnabled)~="function" or api.outlineEnabled()
  if outline and type(a.shouldOutline)=="function" then outline=a:shouldOutline() end
  if outline and b and love.graphics.setDepthMode then
    pcall(love.graphics.setDepthMode,"lequal",false)
    for _,p in ipairs(a.rig.parts or {}) do if p.outlineMesh then pcall(Voxel3D.draw,p.outlineMesh,b,mat,0,mat) end end
    pcall(love.graphics.setDepthMode,"lequal",true)
  end
  for _,p in ipairs(a.rig.parts or {}) do if p.mesh and p.texture then pcall(Voxel3D.draw,p.mesh,p.texture,mat,0,mat) end end
end

local DIRS={{1,0},{-1,0},{0,1},{0,-1}}
local function waterAt(map,x,z)
  if not (map and map.isWaterCell) then return false end
  local ok,v=pcall(map.isWaterCell,map,x,z);return ok and v or false
end
local function setTarget(m,cx,cz)
  m.tcx,m.tcz=cx,cz
  m.tx,_,m.tz=pos(cx,cz,m.y)
end
local function randomWaterStep(map,m,awayX,awayZ)
  local candidates={}
  for _,d in ipairs(DIRS) do
    local x,z=m.cx+d[1],m.cz+d[2]
    if waterAt(map,x,z) and not occupied(x,z,m) then
      local score=0
      if awayX then
        local dx,dz=x-awayX,z-awayZ;score=dx*dx+dz*dz
      end
      candidates[#candidates+1]={x,z,score}
    end
  end
  if #candidates==0 then return false end
  if awayX then table.sort(candidates,function(a,b) return a[3]>b[3] end) end
  local c=awayX and candidates[1] or candidates[rnd(1,#candidates)]
  setTarget(m,c[1],c[2]);return true
end
local function moveMember(map,m,dt)
  -- Carried sea prey follows directly under the attacking bird, matching the
  -- existing flying-ecology carry presentation instead of being knocked backward.
  if m.carriedBy then
    local b=m.carriedBy
    m.x,m.z=b.x,b.z
    m.y=b.y-10
    m.tx,m.tz,m.tcx,m.tcz=nil,nil,nil,nil
    local anim,wobble=waterMoveAnim(m.actor,m.dex)
    if m.lastAnim~=anim then m.actor:setAnimation(anim);m.lastAnim=anim end
    m.wobble=false
    m.actor:setPosition(m.x,m.y,m.z);m.actor:setVisible(false);m.actor:update(dt)
    return
  end
  m.moveClock=(m.moveClock or 0)-dt
  if not m.tx and m.moveClock<=0 then
    randomWaterStep(map,m)
    m.moveClock=1.4+rnd01()*3.2
  end
  local moving=false
  if m.tx then
    local dx,dz=m.tx-m.x,m.tz-m.z
    local d=math.sqrt(dx*dx+dz*dz)
    local speed=(m.fleeClock or 0)>0 and FLEE_SPEED or SWIM_SPEED
    if d<0.6 then
      m.x,m.z=m.tx,m.tz;m.cx,m.cz=m.tcx,m.tcz;m.tx,m.tz=nil,nil
    else
      local q=math.min(d,speed*dt);m.x=m.x+dx/d*q;m.z=m.z+dz/d*q
      m.actor:setYaw(math.atan2(dx,dz));moving=true
    end
  end
  if (m.fleeClock or 0)>0 then m.fleeClock=m.fleeClock-dt end
  if (m.surfaceLock or 0)>0 then
    m.surfaceLock=m.surfaceLock-dt
    if TENTACOOL_FAMILY[m.dex] then m.y=1.2;m.style="surface" end
  end
  -- Tentacool can drift between surface and submerged states over time, but
  -- never submerges while actively escaping a bird strike.
  if TENTACOOL_FAMILY[m.dex] and (m.surfaceLock or 0)<=0 and not moving and rnd01()<dt*0.05 then
    if m.style=="under" then m.y=1.2;m.style="surface" else m.y=-4.5;m.style="under" end
  end
  -- Quest Water Ecology uses the exact authored water_idle role (Mmotion_idle_float).
  local anim,wobble=waterMoveAnim(m.actor,m.dex)
  if m.lastAnim~=anim then m.actor:setAnimation(anim);m.lastAnim=anim end
  m.wobble=wobble
  local drawY=m.y
  if wobble then
    m.wobblePhase=(m.wobblePhase or 0)+dt*3.2
    drawY=drawY+math.sin(m.wobblePhase)*0.45
  end
  m.actor:setPosition(m.x,drawY,m.z);m.actor:setVisible(false);m.actor:update(dt)
end

local function spawnOne()
  if #waterCells==0 then return false end
  local species,dex=pickWaterSpecies();if not dex then return false end
  for _=1,40 do
    local c=waterCells[rnd(1,#waterCells)]
    if c and not occupied(c[1],c[2]) then return createMember(species,dex,c[1],c[2])~=nil end
  end
  return false
end

local function targetCount()
  if #waterCells==0 or not waterDist then return 0 end
  return clamp(math.floor(#waterCells/20+0.5),2,10)
end

local function removeMember(m)
  for i=#members,1,-1 do if members[i]==m then destroyMember(m);table.remove(members,i);return end end
end

local function touch(world,m)
  local p=world and world.player;if not p then return false end
  local px,pz=tonumber(p.x),tonumber(p.z);if not px or not pz then return false end
  local dx,dz=m.x-px,m.z-pz
  return dx*dx+dz*dz<=TOUCH_RADIUS*TOUCH_RADIUS
end

local function beginBattle(m)
  if battleLock or not m then return false end
  local api=wildAPI();if type(api.startDexEncounter)~="function" then return false end
  battleLock=true
  local started=api.startDexEncounter(m.dex,m.level,function()
    battleLock=false
  end)
  if started then removeMember(m);return true end
  battleLock=false;return false
end

local function globallyWildDex(dex)
  local function slotDex(slot)
    return type(slot)=="table" and slot.species and dexOfSpecies(slot.species) or nil
  end
  local function scanSlots(slots)
    if type(slots)~="table" then return false end
    if slots[1] then
      for _,slot in ipairs(slots) do if slotDex(slot)==dex then return true end end
    else
      for _,list in pairs(slots) do if scanSlots(list) then return true end end
    end
    return false
  end
  -- Native + optional custom tables obey the same availability rule.
  for _,data in ipairs(waterEncounterSources()) do
    for _,enc in pairs(data) do
      if type(enc)=="table" then
        for _,kind in ipairs({"grass","water"}) do
          local block=enc[kind]
          if block and (block.rate==nil or (tonumber(block.rate) or 0)>0) and scanSlots(block.slots) then return true end
        end
      end
    end
  end
  return false
end

local function spawnBird()
  if bird or #members==0 or not birdEcologyEnabled() then return false end
  local prey=members[rnd(1,#members)];if not (prey and prey.actor) then return false end
  local predators={}
  if globallyWildDex(18) then predators[#predators+1]=18 end -- Pidgeot
  if globallyWildDex(22) then predators[#predators+1]=22 end -- Fearow
  -- Noctowl is eligible only when the live game both makes it obtainable and
  -- the existing native-night probe says night is active.
  local fly=mod.exports and mod.exports.quest_flying_overworld
  if globallyWildDex(164) and fly and type(fly.nightActive)=="function" then
    local ok,night=pcall(fly.nightActive,activeMapId)
    if ok and night then predators[#predators+1]=164 end
  end
  if #predators==0 then return false end
  local dex=predators[rnd(1,#predators)]
  local api=importer();if not (api and type(api.createActor)=="function") then return false end
  local angle=rnd01()*math.pi*2
  local dist=CELL*(5+rnd01()*3)
  local x=prey.x+math.cos(angle)*dist
  local z=prey.z+math.sin(angle)*dist
  local a=api.createActor(dex,{manual=true,visible=false,x=x,y=BIRD_ALTITUDE,z=z})
  if not a then return false end
  if a.setGroundY then a:setGroundY(0) end
  a:setAnimation("fly");a:setVisible(false)
  bird={dex=dex,actor=a,x=x,y=BIRD_ALTITUDE,z=z,target=prey,phase="orbit",timer=BIRD_ORBIT_TIME,angle=angle}
  return true
end

local function updateBird(map,dt)
  if not bird then return end
  local b=bird;local t=b.target
  if b.phase~="escape" and not (t and t.actor) then clearBird();return end

  if b.phase=="orbit" then
    b.timer=b.timer-dt;b.angle=b.angle+dt*2.0
    b.x=t.x+math.cos(b.angle)*24;b.z=t.z+math.sin(b.angle)*24;b.y=BIRD_ALTITUDE
    if b.timer<=0 then b.phase="swoop" end

  elseif b.phase=="swoop" then
    local tx,ty,tz=t.x,math.max(t.y+5,4),t.z
    local dx,dy,dz=tx-b.x,ty-b.y,tz-b.z
    local d=math.sqrt(dx*dx+dy*dy+dz*dz)
    if d<7 then
      -- Preserve the dive direction so the bird continues THROUGH the target.
      -- This prevents the old visual where it instantly reversed and flew backward.
      local dl=math.sqrt(dx*dx+dz*dz)
      if dl<0.001 then dx,dz=math.cos(b.actorYaw or 0),math.sin(b.actorYaw or 0);dl=1 end
      b.dirx,b.dirz=dx/dl,dz/dl

      if tonumber(t.dex)==73 then
        -- Tentacruel is too large to carry. It stays in the water and flees while
        -- the bird completes its pass in the SAME direction as the dive.
        t.fleeClock=4.0
        t.surfaceLock=4.0
        t.y=1.2;t.style="surface"
        randomWaterStep(map,t,b.x/CELL,b.z/CELL)
        b.phase="escape"
        b.ex,b.ez=b.x+b.dirx*220,b.z+b.dirz*220
        b.escapeTimer=3.0
      else
        -- All other water-ecology prey can be visibly carried away, like normal
        -- Flying Ecology. Keep the existing actor alive and attached below the bird.
        t.carriedBy=b
        t.fleeClock=0;t.surfaceLock=0
        t.tx,t.tz,t.tcx,t.tcz=nil,nil,nil,nil
        b.phase="carry"
        b.carryTimer=3.0
      end
    else
      local q=math.min(d,BIRD_SWOOP_SPEED*dt);b.x=b.x+dx/d*q;b.y=b.y+dy/d*q;b.z=b.z+dz/d*q
    end

  elseif b.phase=="carry" then
    b.carryTimer=(b.carryTimer or 3.0)-dt
    b.y=math.min(BIRD_ALTITUDE+24,b.y+BIRD_ESCAPE_SPEED*0.10*dt)
    local q=BIRD_ESCAPE_SPEED*dt
    b.x=b.x+(b.dirx or 1)*q
    b.z=b.z+(b.dirz or 0)*q
    if t and t.actor then
      t.x,t.z=b.x,b.z
      t.y=b.y-10
      t.actor:setPosition(t.x,t.y,t.z)
      t.actor:setVisible(false)
    end
    if b.carryTimer<=0 then
      if t then
        t.carriedBy=nil
        removeMember(t)
      end
      b.target=nil
      b.phase="escape"
      b.ex,b.ez=b.x+(b.dirx or 1)*150,b.z+(b.dirz or 0)*150
      b.escapeTimer=2.0
    end

  else
    local dx,dz=(b.ex or b.x+(b.dirx or 1)*220)-b.x,(b.ez or b.z+(b.dirz or 0)*220)-b.z
    local d=math.sqrt(dx*dx+dz*dz)
    b.escapeTimer=(b.escapeTimer or 3.0)-dt
    b.y=math.min(BIRD_ALTITUDE+28,b.y+BIRD_ESCAPE_SPEED*0.12*dt)
    if b.escapeTimer<=0 or d<3 then clearBird();return end
    if d>0.001 then
      local q=math.min(d,BIRD_ESCAPE_SPEED*dt);b.x=b.x+dx/d*q;b.z=b.z+dz/d*q
    end
  end

  if bird then
    local yawx,yawz
    if b.phase=="carry" or b.phase=="escape" then
      yawx,yawz=b.dirx or 1,b.dirz or 0
    elseif t then
      yawx,yawz=t.x-b.x,t.z-b.z
    end
    if yawx and math.abs(yawx)+math.abs(yawz)>0.01 then b.actor:setYaw(math.atan2(yawx,yawz)) end
    b.actor:setPosition(b.x,b.y,b.z);b.actor:setVisible(false);b.actor:update(dt)
  end
end

local comp=companion()
if not comp then error("QUEST_WATER_ECOLOGY: voxel companion unavailable",0) end
local imp=importer();if imp and type(imp.Voxel3D)=="function" then local ok,v=pcall(imp.Voxel3D);if ok then Voxel3D=v end end

local spec={
  api=1,id="quest.water.ecology",name="Quest Water Ecology",version="0.2.6",priority=28,
  requires={"render_phases","world_snapshot"},optional={},
  attach=function() servicesReady=true end,
  worldChanged=function() clear();activeMapId=nil;spawnClock=0;availabilityClock=0;birdClock=4+rnd01()*5 end,
  render={opaque_after_terrain=function(context)
    local world=context and context.world
    local ow=(mod.game and mod.game.world) or (Game and Game.overworld)
    if not enabled() then if #members>0 or bird then clear() end;return end
    if not (servicesReady and world and ow and ow.map and ow.player) then return end
    local map=ow.map
    local id=map.id
    if activeMapId~=id then
      clear();activeMapId=id
      waterDist=loadWaterDistribution(id)
      scanWater(map)
      spawnClock=0;availabilityClock=0;birdClock=4+rnd01()*5
    end
    if #waterCells==0 then return end
    local dt=(context.frame and context.frame.dt) or 1/60

    -- Kanto-Reforged can change species scope/spawn mix without changing maps.
    -- Refresh the live distribution periodically and immediately retire actors
    -- that are no longer obtainable from this map's normal water encounters.
    availabilityClock=(availabilityClock or 0)-dt
    if availabilityClock<=0 then
      local fresh=loadWaterDistribution(id)
      waterDist=fresh
      for i=#members,1,-1 do
        local m=members[i]
        if not distributionHasSpecies(waterDist,m.species) then removeMember(m) end
      end
      availabilityClock=1.25
      if not waterDist then clearBird() end
    end
    if not waterDist then return end

    for i=#members,1,-1 do
      local m=members[i]
      if not battleLock and not m.carriedBy then
        local hit=touch(world,m)
        if hit and not m.contact then if beginBattle(m) then break end
        elseif not hit then m.contact=false end
      end
      if m.actor then moveMember(map,m,dt);drawActor(m.actor) end
    end

    spawnClock=spawnClock-dt
    if spawnClock<=0 then
      local want=targetCount()
      if #members<want then spawnOne() end
      spawnClock=RESPAWN_INTERVAL
    end

    birdClock=birdClock-dt
    if birdClock<=0 then
      if not bird and rnd01()<BIRD_SPAWN_CHANCE then spawnBird() end
      birdClock=BIRD_SCAN_MIN+rnd01()*(BIRD_SCAN_MAX-BIRD_SCAN_MIN)
    end
    updateBird(map,dt)
    if bird and bird.actor then drawActor(bird.actor) end
  end},
  invalidate=function() clear();activeMapId=nil end,
  dispose=function() clear();if BLACK and BLACK.release then pcall(BLACK.release,BLACK) end;BLACK=nil end,
}
local h,err=comp.register(spec)
if not h then error("QUEST_WATER_ECOLOGY registration failed: "..tostring(err),0) end
mod.exports.quest_water_ecology={api=1,clear=clear,count=function() return #members end}
